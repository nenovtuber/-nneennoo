# FaceTracker（iPhone 端）

## 流程
開始畫面 → 選擇模式 → 連線模式／手機模式。每個畫面右上角都有設定按鈕。
- **連線模式**：手機當追蹤器，把表情數據傳到電腦。畫面只有狀態、電腦 IP、開始／停止。
- **手機模式**：在手機上匯入並顯示 Live2D 模型（含個人校正、參數對應、快捷按鈕、參數手冊）。
- **設定**：切換使用模式、外觀（跟隨系統／淺色／深色）、Port、傳送頻率、黑畫面省電、自動開始、同時傳送到電腦、執行庫、啟動選項。

## 建置（GitHub Actions，不需要 Mac）
1. 把這個資料夾的**內容**放到 GitHub 倉庫根目錄：`project.yml`、`Sources/`（共 11 個 .swift）、`.github/workflows/build.yml`。
2. **刪除倉庫裡舊的 `Sources/ContentView.swift`**（已被 RootView 等檔案取代）。
3. Actions 分頁 → Build IPA。
4. Releases → Latest build 下載 `FaceTracker.ipa`，用 AltStore／Sideloadly 側載。

## Sources 裡的檔案
FaceTrackerApp、RootView、Theme、SplashView、ModeSelectView、ConnectView、PhoneView、SettingsView、Tracker、ModelFeature、Live2DHTML

## 手機模式的設定面板（齒輪）
分頁由左到右：一般、快捷按鈕、個人校正、咬牙判定、參數對應、參數說明。畫質與背景在「一般」裡。

## 追蹤範圍與中斷容忍（設定 → 追蹤）
- **追蹤範圍**：標準／廣角。廣角使用視野較大的相機格式，臉靠邊或角度大時比較不容易丟失（可能降為 30 FPS）。
- **中斷容忍**：短 0.3 秒／中 0.8 秒／長 1.5 秒。臉短暫失去追蹤時，持續送出最後的有效姿勢。

## 咬牙判定與數值優化（手機模式的設定面板）
- **咬牙判定**分頁：即時狀態、咬牙校正（① 記錄放鬆、② 記錄咬牙，自動算出你自己的門檻）、門檻、手感（靈敏度、咬下速度、放開速度）、恢復預設。
- **一般**分頁：頭部靈敏度、雜訊過濾、眨眼補償、雙眼眨眼同步。
- **參數對應**：每條對應多了「曲線」滑桿。
- 眨眼、說話、眉毛、眼球會自動套用各自適合的平滑與雜訊門檻。
