import SwiftUI
import UIKit

// 連線模式：只有狀態、電腦 IP、開始／停止。其他設定都在右上角的設定裡。
struct ConnectView: View {
    @ObservedObject var tracker: Tracker
    let onSettings: () -> Void

    @AppStorage("host") private var host = ""
    @AppStorage("port") private var port = "39539"
    @AppStorage("fps") private var fps = 60
    @AppStorage("blackout") private var blackout = true
    @AppStorage("autostart") private var autostart = false

    @State private var dimmed = false
    @State private var savedBrightness: CGFloat = 0.5
    @State private var didAutoStart = false
    @Environment(\.scenePhase) private var scenePhase

    init(tracker: Tracker, onSettings: @escaping () -> Void) {
        self.tracker = tracker
        self.onSettings = onSettings
    }

    private var orbKind: StatusOrb.Kind {
        if !tracker.isRunning { return .idle }
        return tracker.pcReachable ? .live : .waiting
    }

    private var statusTitle: String {
        if !tracker.isRunning { return "尚未連線" }
        return tracker.pcReachable ? "已連線" : "等待電腦回應"
    }

    private var statusDetail: String {
        if !tracker.isRunning {
            return tracker.connection == "未連線" ? "輸入電腦畫面上顯示的 IP，然後開始追蹤。" : tracker.connection
        }
        var text = "\(tracker.faceStatus)　·　\(tracker.sentPerSec) 包/秒"
        if !tracker.pcReachable { text += "\n\(tracker.connection)" }
        return text
    }

    var body: some View {
        ZStack {
            content
            if dimmed { dimOverlay }
        }
        .onAppear {
            if autostart && !didAutoStart && !host.isEmpty && !tracker.isRunning {
                didAutoStart = true
                startAll()
            }
        }
        .onDisappear { if dimmed { exitDim() } }
        .onChange(of: scenePhase) { phase in
            if phase != .active && dimmed { exitDim() }
        }
    }

    private var content: some View {
        VStack(spacing: 0) {
            TopBar(title: "連線模式", subtitle: "傳送表情數據到電腦", onSettings: onSettings)
            Spacer()
            StatusOrb(kind: orbKind)
            Text(statusTitle)
                .font(.system(size: 24, weight: .semibold))
                .foregroundColor(Palette.text)
                .padding(.top, 30)
            Text(statusDetail)
                .font(.system(size: 14))
                .foregroundColor(Palette.muted)
                .multilineTextAlignment(.center)
                .padding(.top, 8)
                .padding(.horizontal, 20)
            Spacer()
            VStack(spacing: 14) {
                VStack(alignment: .leading, spacing: 8) {
                    SectionLabel("電腦 IP")
                    TextField("例如 192.168.1.20", text: $host)
                        .font(.system(size: 22, weight: .regular, design: .monospaced))
                        .foregroundColor(Palette.text)
                        .keyboardType(.numbersAndPunctuation)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .disabled(tracker.isRunning)
                }
                .card()
                Button(action: toggle) {
                    Text(tracker.isRunning ? "停止" : "開始追蹤")
                }
                .buttonStyle(PrimaryButtonStyle(filled: !tracker.isRunning))
            }
        }
        .padding(.horizontal, 22)
        .padding(.top, 12)
        .padding(.bottom, 20)
    }

    private var dimOverlay: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 8) {
                Text(tracker.pcReachable ? "追蹤中・電腦已連線" : "追蹤中・等待電腦回應")
                    .foregroundColor(Color(white: 0.3))
                Text("點一下螢幕離開省電模式")
                    .font(.footnote).foregroundColor(Color(white: 0.22))
            }
        }
        .onTapGesture { exitDim() }
    }

    private func enterDim() {
        savedBrightness = UIScreen.main.brightness
        UIScreen.main.brightness = 0.01
        dimmed = true
    }

    private func exitDim() {
        UIScreen.main.brightness = savedBrightness
        dimmed = false
    }

    private func toggle() {
        if tracker.isRunning {
            tracker.stop()
            if dimmed { exitDim() }
        } else {
            startAll()
        }
    }

    private func startAll() {
        tracker.start(host: host.trimmingCharacters(in: .whitespaces),
                      port: UInt16(port) ?? 39539,
                      fps: fps)
        if tracker.isRunning && blackout { enterDim() }
    }
}
