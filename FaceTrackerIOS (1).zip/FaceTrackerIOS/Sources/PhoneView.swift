import SwiftUI

// 手機模式：準備執行庫、匯入模型、開啟模型畫面。詳細設定在模型畫面的齒輪與右上角設定。
struct PhoneView: View {
    @ObservedObject var tracker: Tracker
    @ObservedObject var store: ModelStore
    let onSettings: () -> Void
    let onChangeMode: (AppMode) -> Void

    @AppStorage("host") private var host = ""
    @AppStorage("port") private var port = "39539"
    @AppStorage("fps") private var fps = 60
    @AppStorage("alsoSend") private var alsoSend = true
    @AppStorage("selectedModel") private var selectedModel = ""
    @AppStorage("appearance") private var appearance = "system"

    @State private var showModel = false
    @State private var showPicker = false
    @State private var localOnlyStarted = false

    init(tracker: Tracker, store: ModelStore,
         onSettings: @escaping () -> Void,
         onChangeMode: @escaping (AppMode) -> Void) {
        self.tracker = tracker
        self.store = store
        self.onSettings = onSettings
        self.onChangeMode = onChangeMode
    }

    private var canOpen: Bool {
        store.libsReady && !selectedModel.isEmpty && store.models.contains(selectedModel)
    }

    var body: some View {
        VStack(spacing: 0) {
            TopBar(title: "手機模式", subtitle: "在手機上顯示 Live2D 模型", onSettings: onSettings)
                .padding(.horizontal, 22)
                .padding(.top, 12)
            ScrollView {
                VStack(spacing: 14) {
                    libsCard
                    modelsCard
                    if !store.status.isEmpty {
                        Text(store.status)
                            .font(.system(size: 12))
                            .foregroundColor(Palette.muted)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 4)
                    }
                }
                .padding(.horizontal, 22)
                .padding(.top, 22)
                .padding(.bottom, 12)
            }
            Button(action: openModel) { Text("開啟模型畫面") }
                .buttonStyle(PrimaryButtonStyle(filled: true))
                .opacity(canOpen ? 1 : 0.35)
                .disabled(!canOpen)
                .padding(.horizontal, 22)
                .padding(.bottom, 20)
        }
        .fullScreenCover(isPresented: $showModel, onDismiss: modelClosed) {
            ModelScreen(modelName: selectedModel,
                        store: store,
                        tracker: tracker,
                        onClose: { showModel = false },
                        onSendOnly: {
                            showModel = false
                            DispatchQueue.main.async { onChangeMode(.connect) }
                        })
                .preferredColorScheme(Appearance.scheme(appearance))
        }
        .sheet(isPresented: $showPicker) {
            FolderPicker { url in
                store.importModel(from: url)
                showPicker = false
            }
        }
    }

    private var libsCard: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                SectionLabel("執行庫")
                Text(store.libsReady ? "已安裝" : "尚未安裝")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Palette.text)
                if !store.libsReady {
                    Text("第一次使用需要下載，約 1～2 MB，需要網路。")
                        .font(.system(size: 12))
                        .foregroundColor(Palette.muted)
                }
            }
            Spacer()
            if !store.libsReady {
                Button(action: { store.downloadLibs() }) {
                    Text(store.busy ? "下載中…" : "下載")
                }
                .buttonStyle(SmallButtonStyle())
                .disabled(store.busy)
            }
        }
        .card()
    }

    private var modelsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                SectionLabel("模型")
                Spacer()
                Button(action: { showPicker = true }) { Text("匯入") }
                    .buttonStyle(SmallButtonStyle())
            }
            if store.models.isEmpty {
                Text("還沒有模型。請先在「檔案」App 把模型 zip 解壓縮成資料夾，再按「匯入」選擇那個資料夾，資料夾裡要有 .model3.json。")
                    .font(.system(size: 13))
                    .foregroundColor(Palette.muted)
            } else {
                VStack(spacing: 0) {
                    ForEach(store.models, id: \.self) { name in
                        modelRow(name)
                        if name != store.models.last { Divider().background(Palette.line) }
                    }
                }
            }
        }
        .card()
    }

    private func modelRow(_ name: String) -> some View {
        HStack(spacing: 12) {
            Button(action: { selectedModel = name }) {
                HStack(spacing: 12) {
                    Image(systemName: selectedModel == name ? "largecircle.fill.circle" : "circle")
                        .font(.system(size: 18))
                        .foregroundColor(selectedModel == name ? Palette.text : Palette.muted)
                    Text(name)
                        .font(.system(size: 16))
                        .foregroundColor(Palette.text)
                        .lineLimit(1)
                    Spacer()
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(PressableStyle())
            Button(action: {
                store.deleteModel(name)
                if selectedModel == name { selectedModel = "" }
            }) {
                Image(systemName: "trash")
                    .font(.system(size: 15))
                    .foregroundColor(Palette.muted)
                    .frame(width: 36, height: 36)
            }
        }
        .padding(.vertical, 6)
    }

    private func openModel() {
        let trimmed = host.trimmingCharacters(in: .whitespaces)
        if !tracker.isRunning {
            tracker.start(host: trimmed, port: UInt16(port) ?? 39539, fps: fps,
                          sendToPC: alsoSend && !trimmed.isEmpty)
            if !tracker.isRunning { return }   // 啟動失敗（例如裝置不支援臉部追蹤）
            localOnlyStarted = true
        }
        showModel = true
    }

    private func modelClosed() {
        if localOnlyStarted {
            tracker.stop()
            localOnlyStarted = false
        }
    }
}
