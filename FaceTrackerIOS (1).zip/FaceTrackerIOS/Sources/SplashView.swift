import SwiftUI

// 開始畫面
struct SplashView: View {
    @State private var appear = false

    var body: some View {
        ZStack {
            Palette.bg.ignoresSafeArea()
            VStack(spacing: 30) {
                FaceMark()
                    .frame(width: 96, height: 96)
                    .scaleEffect(appear ? 1 : 0.88)
                    .opacity(appear ? 1 : 0)
                VStack(spacing: 10) {
                    Text("FACEBRIDGE")
                        .font(.system(size: 22, weight: .light))
                        .kerning(8)
                        .foregroundColor(Palette.text)
                    Text("Face tracking for Live2D")
                        .font(.system(size: 12))
                        .kerning(1.5)
                        .foregroundColor(Palette.muted)
                }
                .opacity(appear ? 1 : 0)
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.9)) { appear = true }
        }
    }
}

// 簡約線條臉：圓形外框、兩個眼睛、微笑弧線
struct FaceMark: View {
    var body: some View {
        ZStack {
            Circle().stroke(Palette.text, lineWidth: 2)
            Path { p in
                p.addEllipse(in: CGRect(x: 31, y: 36, width: 9, height: 9))
                p.addEllipse(in: CGRect(x: 56, y: 36, width: 9, height: 9))
            }
            .fill(Palette.text)
            Path { p in
                p.move(to: CGPoint(x: 32, y: 60))
                p.addQuadCurve(to: CGPoint(x: 64, y: 60), control: CGPoint(x: 48, y: 76))
            }
            .stroke(Palette.text, style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
        }
    }
}
