import SwiftUI

// 主流程：開始畫面 → 選擇模式 → 連線模式／手機模式。右上角的設定按鈕在每個畫面都有。
struct RootView: View {
    enum Screen { case splash, select, connect, phone }

    @AppStorage("mode") private var modeRaw = ""
    @AppStorage("rememberMode") private var rememberMode = false
    @AppStorage("showSplash") private var showSplash = true
    @AppStorage("appearance") private var appearance = "system"

    @StateObject private var tracker = Tracker()
    @StateObject private var store = ModelStore()
    @State private var screen: Screen = .splash
    @State private var showSettings = false

    private var currentMode: AppMode? {
        switch screen {
        case .connect: return .connect
        case .phone: return .phone
        default: return nil
        }
    }

    var body: some View {
        ZStack {
            Palette.bg.ignoresSafeArea()
            switch screen {
            case .splash:
                SplashView().transition(.opacity)
            case .select:
                ModeSelectView(onPick: { applyMode($0) },
                               onSettings: { showSettings = true })
                    .transition(.opacity)
            case .connect:
                ConnectView(tracker: tracker, onSettings: { showSettings = true })
                    .transition(.opacity)
            case .phone:
                PhoneView(tracker: tracker,
                          store: store,
                          onSettings: { showSettings = true },
                          onChangeMode: { applyMode($0) })
                    .transition(.opacity)
            }
        }
        .preferredColorScheme(Appearance.scheme(appearance))
        .sheet(isPresented: $showSettings) {
            SettingsView(currentMode: currentMode,
                         onChangeMode: { applyMode($0) },
                         onBackToSelect: { backToSelect() },
                         store: store)
                .preferredColorScheme(Appearance.scheme(appearance))
        }
        .task {
            if showSplash { try? await Task.sleep(nanoseconds: 1_700_000_000) }
            withAnimation(.easeInOut(duration: 0.45)) {
                if rememberMode, let m = AppMode(rawValue: modeRaw) {
                    screen = (m == .connect) ? .connect : .phone
                } else {
                    screen = .select
                }
            }
        }
    }

    private func applyMode(_ mode: AppMode) {
        if tracker.isRunning { tracker.stop() }
        modeRaw = mode.rawValue
        withAnimation(.easeInOut(duration: 0.35)) {
            screen = (mode == .connect) ? .connect : .phone
        }
    }

    private func backToSelect() {
        if tracker.isRunning { tracker.stop() }
        withAnimation(.easeInOut(duration: 0.35)) { screen = .select }
    }
}
