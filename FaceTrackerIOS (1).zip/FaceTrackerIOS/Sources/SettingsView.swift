import SwiftUI

// 設定：切換使用模式、黑白模式（外觀）、連線與手機模式的選項
struct SettingsView: View {
    let currentMode: AppMode?
    let onChangeMode: (AppMode) -> Void
    let onBackToSelect: () -> Void
    @ObservedObject var store: ModelStore

    @Environment(\.dismiss) private var dismiss
    @AppStorage("appearance") private var appearance = "system"
    @AppStorage("port") private var port = "39539"
    @AppStorage("fps") private var fps = 60
    @AppStorage("blackout") private var blackout = true
    @AppStorage("autostart") private var autostart = false
    @AppStorage("alsoSend") private var alsoSend = true
    @AppStorage("rememberMode") private var rememberMode = false
    @AppStorage("showSplash") private var showSplash = true
    @AppStorage("wideRange") private var wideRange = true
    @AppStorage("lossGrace") private var lossGrace = 0.8

    init(currentMode: AppMode?,
         onChangeMode: @escaping (AppMode) -> Void,
         onBackToSelect: @escaping () -> Void,
         store: ModelStore) {
        self.currentMode = currentMode
        self.onChangeMode = onChangeMode
        self.onBackToSelect = onBackToSelect
        self.store = store
    }

    private var modeBinding: Binding<String> {
        Binding<String>(
            get: { currentMode?.rawValue ?? "" },
            set: { value in
                if let m = AppMode(rawValue: value) {
                    onChangeMode(m)
                    dismiss()
                }
            })
    }

    var body: some View {
        ZStack {
            Palette.bg.ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    Text("設定")
                        .font(.system(size: 30, weight: .semibold))
                        .foregroundColor(Palette.text)
                    Spacer()
                    Button(action: { dismiss() }) { Text("完成") }
                        .buttonStyle(SmallButtonStyle())
                }
                .padding(.horizontal, 22)
                .padding(.top, 22)
                .padding(.bottom, 12)

                ScrollView {
                    VStack(spacing: 14) {
                        modeCard
                        appearanceCard
                        trackingCard
                        connectCard
                        phoneCard
                        startupCard
                        aboutCard
                    }
                    .padding(.horizontal, 22)
                    .padding(.bottom, 30)
                }
            }
        }
    }

    private var modeCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionLabel("使用模式")
            Picker("使用模式", selection: modeBinding) {
                Text("連線模式").tag("connect")
                Text("手機模式").tag("phone")
            }
            .pickerStyle(.segmented)
            Text("連線模式：手機把表情數據傳到電腦。手機模式：在手機上顯示 Live2D 模型。")
                .font(.system(size: 12))
                .foregroundColor(Palette.muted)
            Button(action: {
                onBackToSelect()
                dismiss()
            }) { Text("回到模式選擇畫面") }
                .buttonStyle(SmallButtonStyle())
        }
        .card()
    }

    private var appearanceCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionLabel("外觀（黑白模式）")
            Picker("外觀", selection: $appearance) {
                Text("跟隨系統").tag("system")
                Text("淺色").tag("light")
                Text("深色").tag("dark")
            }
            .pickerStyle(.segmented)
        }
        .card()
    }

    private var trackingCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionLabel("追蹤（兩種模式共用）")
            VStack(alignment: .leading, spacing: 8) {
                Text("追蹤範圍").font(.system(size: 16)).foregroundColor(Palette.text)
                Picker("追蹤範圍", selection: $wideRange) {
                    Text("標準").tag(false)
                    Text("廣角").tag(true)
                }
                .pickerStyle(.segmented)
                Text("廣角會改用視野較大的相機格式，臉靠邊或角度比較大時比較不容易丟失，但可能降為 30 FPS。")
                    .font(.system(size: 12)).foregroundColor(Palette.muted)
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("中斷容忍").font(.system(size: 16)).foregroundColor(Palette.text)
                Picker("中斷容忍", selection: $lossGrace) {
                    Text("短").tag(0.3)
                    Text("中").tag(0.8)
                    Text("長").tag(1.5)
                }
                .pickerStyle(.segmented)
                Text("臉短暫失去追蹤時，持續送出最後的有效姿勢多久，避免臉稍微轉出去就中斷。變更在下次開始追蹤時生效。")
                    .font(.system(size: 12)).foregroundColor(Palette.muted)
            }
        }
        .card()
    }

    private var connectCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionLabel("連線模式")
            VStack(alignment: .leading, spacing: 8) {
                Text("Port").font(.system(size: 16)).foregroundColor(Palette.text)
                TextField("39539", text: $port)
                    .font(.system(size: 17, design: .monospaced))
                    .foregroundColor(Palette.text)
                    .keyboardType(.numberPad)
                    .padding(12)
                    .background(Palette.surface2)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("傳送頻率").font(.system(size: 16)).foregroundColor(Palette.text)
                Picker("傳送頻率", selection: $fps) {
                    Text("30").tag(30)
                    Text("60").tag(60)
                }
                .pickerStyle(.segmented)
                Text("省電選 30，要流暢選 60。追蹤中無法更改，需停止後再改。")
                    .font(.system(size: 12)).foregroundColor(Palette.muted)
            }
            ToggleRow(title: "追蹤時黑畫面省電", detail: "開始後螢幕變黑並調暗，點一下離開。", isOn: $blackout)
            ToggleRow(title: "開啟時自動開始追蹤", detail: "進入連線模式時，已填電腦 IP 就直接開始。", isOn: $autostart)
        }
        .card()
    }

    private var phoneCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionLabel("手機模式")
            ToggleRow(title: "同時傳送到電腦",
                      detail: "顯示模型的同時，也把表情數據傳到電腦（需要已填電腦 IP）。",
                      isOn: $alsoSend)
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("執行庫").font(.system(size: 16)).foregroundColor(Palette.text)
                    Text(store.libsReady ? "已安裝" : "尚未安裝")
                        .font(.system(size: 12)).foregroundColor(Palette.muted)
                }
                Spacer()
                Button(action: { store.downloadLibs() }) {
                    Text(store.busy ? "下載中…" : (store.libsReady ? "重新下載" : "下載"))
                }
                .buttonStyle(SmallButtonStyle())
                .disabled(store.busy)
            }
            Text("模型的對應、校正、快捷按鈕等詳細設定，在模型畫面右上角的齒輪裡。")
                .font(.system(size: 12)).foregroundColor(Palette.muted)
        }
        .card()
    }

    private var startupCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionLabel("啟動")
            ToggleRow(title: "顯示開始畫面", detail: nil, isOn: $showSplash)
            ToggleRow(title: "記住上次的模式", detail: "開啟 App 後直接進入上次的模式，跳過選擇畫面。", isOn: $rememberMode)
        }
        .card()
    }

    private var aboutCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionLabel("關於")
            Text("FaceBridge 1.0")
                .font(.system(size: 16, weight: .medium)).foregroundColor(Palette.text)
            Text("只傳送表情數字，不顯示、不儲存、不傳送任何臉部影像。")
                .font(.system(size: 12)).foregroundColor(Palette.muted)
        }
        .card()
    }
}
