import SwiftUI

// 選擇使用模式
struct ModeSelectView: View {
    let onPick: (AppMode) -> Void
    let onSettings: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: "選擇模式", subtitle: "之後可以在設定中切換", onSettings: onSettings)
            Spacer().frame(height: 28)
            VStack(spacing: 16) {
                ModeCard(icon: "desktopcomputer",
                         title: "連線模式",
                         detail: "手機當追蹤器，把表情數據傳到電腦。",
                         action: { onPick(.connect) })
                ModeCard(icon: "iphone",
                         title: "手機模式",
                         detail: "在手機上匯入並顯示 Live2D 模型，不需要電腦。",
                         action: { onPick(.phone) })
            }
            Spacer()
            Text("只傳送表情數字，不顯示、不儲存、不傳送任何影像。")
                .font(.system(size: 12))
                .foregroundColor(Palette.muted)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.bottom, 8)
        }
        .padding(.horizontal, 22)
        .padding(.top, 12)
    }
}

struct ModeCard: View {
    let icon: String
    let title: String
    let detail: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                Image(systemName: icon)
                    .font(.system(size: 22, weight: .light))
                    .foregroundColor(Palette.text)
                    .frame(width: 54, height: 54)
                    .background(Palette.surface2)
                    .clipShape(Circle())
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 19, weight: .semibold))
                        .foregroundColor(Palette.text)
                    Text(detail)
                        .font(.system(size: 13))
                        .foregroundColor(Palette.muted)
                        .multilineTextAlignment(.leading)
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Palette.muted)
            }
            .padding(20)
            .frame(maxWidth: .infinity)
            .background(Palette.surface)
            .clipShape(RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(Palette.line, lineWidth: 1))
        }
        .buttonStyle(PressableStyle())
    }
}
