import SwiftUI
import UIKit

// 整個 App 的視覺規範：現代高級灰階。所有顏色都只有灰階，並自動隨深色／淺色切換。

extension UIColor {
    convenience init(hex: UInt32) {
        self.init(red: CGFloat((hex >> 16) & 0xFF) / 255.0,
                  green: CGFloat((hex >> 8) & 0xFF) / 255.0,
                  blue: CGFloat(hex & 0xFF) / 255.0,
                  alpha: 1)
    }
}

enum Palette {
    private static func dyn(_ light: UInt32, _ dark: UInt32) -> Color {
        Color(UIColor { trait in
            trait.userInterfaceStyle == .dark ? UIColor(hex: dark) : UIColor(hex: light)
        })
    }
    static let bg = dyn(0xF4F4F5, 0x0E0E10)         // 背景
    static let surface = dyn(0xFFFFFF, 0x1A1A1D)    // 卡片
    static let surface2 = dyn(0xEDEDEF, 0x252528)   // 次要底色
    static let line = dyn(0xDCDCE0, 0x2C2C30)       // 細線
    static let text = dyn(0x111113, 0xF2F2F3)       // 主要文字
    static let muted = dyn(0x6B6B70, 0x8E8E93)      // 次要文字
    static let accent = dyn(0x111113, 0xF2F2F3)     // 強調（深色模式為亮灰白、淺色模式為近黑）
    static let onAccent = dyn(0xFFFFFF, 0x0E0E10)   // 強調底色上的文字
}

enum AppMode: String {
    case connect
    case phone
}

enum Appearance {
    static func scheme(_ raw: String) -> ColorScheme? {
        switch raw {
        case "light": return .light
        case "dark": return .dark
        default: return nil
        }
    }
}

// MARK: - 元件

struct PrimaryButtonStyle: ButtonStyle {
    var filled: Bool = true
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 17, weight: .semibold))
            .foregroundColor(filled ? Palette.onAccent : Palette.text)
            .frame(maxWidth: .infinity, minHeight: 54)
            .background(filled ? Palette.accent : Color.clear)
            .overlay(RoundedRectangle(cornerRadius: 16)
                        .stroke(filled ? Color.clear : Palette.line, lineWidth: 1.2))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .opacity(configuration.isPressed ? 0.8 : 1)
    }
}

struct SmallButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 13, weight: .medium))
            .foregroundColor(Palette.text)
            .padding(.horizontal, 14).padding(.vertical, 8)
            .background(Palette.surface2)
            .clipShape(Capsule())
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .opacity(configuration.isPressed ? 0.9 : 1)
    }
}

struct CardModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Palette.surface)
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(Palette.line, lineWidth: 1))
    }
}

extension View {
    func card() -> some View { modifier(CardModifier()) }
}

struct SectionLabel: View {
    let text: String
    init(_ text: String) { self.text = text }
    var body: some View {
        Text(text)
            .font(.system(size: 12, weight: .medium))
            .kerning(1.2)
            .foregroundColor(Palette.muted)
    }
}

struct TopBar: View {
    let title: String
    let subtitle: String?
    let onSettings: () -> Void

    var body: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.system(size: 30, weight: .semibold))
                    .foregroundColor(Palette.text)
                if let s = subtitle {
                    Text(s)
                        .font(.system(size: 13))
                        .foregroundColor(Palette.muted)
                }
            }
            Spacer()
            Button(action: onSettings) {
                Image(systemName: "gearshape")
                    .font(.system(size: 18, weight: .regular))
                    .foregroundColor(Palette.text)
                    .frame(width: 46, height: 46)
                    .background(Palette.surface)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Palette.line, lineWidth: 1))
            }
            .buttonStyle(PressableStyle())
        }
    }
}

struct StatusOrb: View {
    enum Kind { case idle, waiting, live }
    let kind: Kind
    @State private var pulse = false

    init(kind: Kind) { self.kind = kind }

    private var icon: String {
        switch kind {
        case .idle: return "power"
        case .waiting: return "wifi"
        case .live: return "checkmark"
        }
    }

    var body: some View {
        ZStack {
            Circle().stroke(Palette.line, lineWidth: 1).frame(width: 230, height: 230)
            Circle().stroke(Palette.line, lineWidth: 1).frame(width: 176, height: 176)
            Circle()
                .fill(kind == .live ? Palette.accent : Palette.surface)
                .overlay(Circle().stroke(Palette.line, lineWidth: 1))
                .frame(width: 118, height: 118)
                .scaleEffect(kind == .waiting && pulse ? 1.08 : 1)
            Image(systemName: icon)
                .font(.system(size: 34, weight: .light))
                .foregroundColor(kind == .live ? Palette.onAccent : Palette.text)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}

struct ToggleRow: View {
    let title: String
    let detail: String?
    @Binding var isOn: Bool

    var body: some View {
        Toggle(isOn: $isOn) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 16)).foregroundColor(Palette.text)
                if let d = detail {
                    Text(d).font(.system(size: 12)).foregroundColor(Palette.muted)
                }
            }
        }
        .toggleStyle(SwitchToggleStyle(tint: Palette.accent))
    }
}
